package com.tryoasnafi.mymoviecatalogue;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.tryoasnafi.mymoviecatalogue.model.Movie;

public class DetailMovieActivity extends AppCompatActivity {
    ImageView imgPhoto;
    TextView tvTitle, tvRelease, tvGenre, tvRuntime, tvDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);

        imgPhoto = findViewById(R.id.img_photo);
        tvTitle = findViewById(R.id.tv_title);
        tvRelease = findViewById(R.id.tv_release_value);
        tvGenre = findViewById(R.id.tv_genre_value);
        tvRuntime = findViewById(R.id.tv_runtime_value);
        tvDescription = findViewById(R.id.tv_description);

        Movie movie = getIntent().getParcelableExtra("Movies");
        tvTitle.setText(movie.getTitle());
        tvRelease.setText(movie.getRelease());
        tvGenre.setText(movie.getGenre());
        tvRuntime.setText(movie.getRuntime());
        tvDescription.setText(movie.getDescription());

        Glide.with(this)
                .load(movie.getPhoto())
                .apply(new RequestOptions().override(140, 200))
                .into(imgPhoto);


    }
}
